package br.com.marceloluizfontana.calc.imc.model

import androidx.databinding.ObservableDouble


class Weight {
    private var weight = ObservableDouble()

    fun getPeso() = this.weight
    fun setPeso(value: Double) {
        this.weight.set(value)
    }
}