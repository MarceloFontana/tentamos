package br.com.marceloluizfontana.calc.imc.model

interface IObserver {
    fun updateUi(data:MutableMap<String,Any>)
}