package br.com.marceloluizfontana.calc.imc.model

import androidx.databinding.ObservableDouble

class Height {

    private var height = ObservableDouble()

    fun getHeight() = this.height
    fun setHeight(value: Double) {
        this.height.set(value)
    }
}
