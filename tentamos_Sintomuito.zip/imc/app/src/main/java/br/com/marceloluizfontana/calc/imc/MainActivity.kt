package br.com.marceloluizfontana.calc.imc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.databinding.DataBindingUtil
import br.com.marceloluizfontana.calc.imc.databinding.ActivityMainBinding
import br.com.marceloluizfontana.calc.imc.model.Height
import br.com.marceloluizfontana.calc.imc.model.Weight
import br.com.marceloluizfontana.calc.imc.repository.BmiAPI

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var alert: AlertDialog
    private val height = Height()
    private val weight = Weight()
    //private val bmi = bmi()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        binding.dataHeight = height
        binding.dataWeight = weight


        // mensagem na tela para load da informação da api após clickar no botao calcular
        binding.calcbutton.setOnClickListener {
            val alert = AlertDialog.Builder(this)

            alert.setTitle("Aguarde...")
            alert.setMessage("Estamos calculando o imc...")
            alert.show()

            //botao para passar a tela de inicio para a tela do calculo da api
            val bmiAPI = BmiAPI()
            bmiAPI.getBMI(applicationContext, this)
            val buttonTela2Iniciar = findViewById<Button>(R.id.button2)
            buttonTela2Iniciar.setOnClickListener{
                val iniciar = Intent(this,buttonTela2Iniciar::class.java)
                startActivity(iniciar)
            }
        }
    }

    fun updateUI(data: MutableMap<String, Any>) {

        if (data.isNotEmpty()) {
            val height = data["altura"] as Double
            val weight = data["peso"] as Double
        }
        //calculo if else para mostrar nivel do bmi

        //if,else if, else.

        //if (bmi <= 17) {
        //println("Muito Abaixo do Peso")
        //}
        //else if (bmi > 17) && (bmi <= 18.49){
        //println("Abaixo do Peso")
        //}
        //else if (bmi >= 18.5) && (bmi >= 24.99){
        //println("Peso Normal")
        //}
        //else if (bmi >= 25) && (bmi <= 29.99){
        // println("Acima do Peso")
        //}
        //else if (bmi >= 30) && (bmi <= 34.99){
        //println("Obesidade")

        //}
        //else if (bmi >= 35) && (bmi <= 39.99){
        // println("Obesidade 2")
        //}
        //else(bmi >= 40){
        // println("Obesidade morbida, vulgo BALEIA ASSASINA!!!!")
        //}

    }


}