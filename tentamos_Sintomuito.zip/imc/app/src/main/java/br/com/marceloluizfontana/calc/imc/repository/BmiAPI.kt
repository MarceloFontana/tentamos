package br.com.marceloluizfontana.calc.imc.repository

import android.content.Context
import android.util.Log
import br.com.marceloluizfontana.calc.imc.MainActivity
import br.com.marceloluizfontana.calc.imc.model.IObserver
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

// Codigo pega a API e converte no layout com as informações dada pelo usuario
class BmiAPI {
    fun getBMI(
        context: Context,
        observer: MainActivity
    ){
        val queue = Volley.newRequestQueue(context)
        val url ="https://body-mass-index-bmi-calculator.p.rapidapi.com/metric"
        val stringRequest = StringRequest(
            Request.Method.GET,
            url,
            {
                    response ->
                if(!response.isNullOrEmpty()){
                    val jsonObj = JSONObject(response)
                    val results = jsonObj.getJSONObject("results")
                    val Bmi = results.getJSONObject("Bmi")
                    val Height = Bmi.getJSONObject("Metro").getDouble("BodyHeight")
                    val weight = Bmi.getJSONObject("Kg").getDouble("bodyFat")

                    val map = mutableMapOf<String,Any>()
                    map["altura"] = Height
                    map["peso"] = weight
                    observer.updateUI(map)
                }
            },
            {
                    error ->  Log.e("APPDEBUG","Erro!!! ${error.message}")
            }
        )
        queue.add(stringRequest)
    }
}